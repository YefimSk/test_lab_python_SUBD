print("hello world!")

